package com.example.photoproject;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PhotoDetailActivity extends AppCompatActivity {

    private ImageView detailImage, likeButton;
    private RecyclerView moreRecyclerView, commentRecyclerView;
    private EditText commentEditText;
    private Button commentSubmitButton;

    private boolean liked = false;
    private List<CommentItem> commentList = new ArrayList<>();
    private CommentAdapter commentAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_detail);

        detailImage = findViewById(R.id.detailImageView);
        likeButton = findViewById(R.id.likeButton);
        commentEditText = findViewById(R.id.commentEditText);
        commentSubmitButton = findViewById(R.id.commentSubmitButton);
        commentRecyclerView = findViewById(R.id.commentRecyclerView);
        moreRecyclerView = findViewById(R.id.moreRecyclerView);

        // 이미지 설정
        String imageUriStr = getIntent().getStringExtra("imageUri");
        if (imageUriStr != null) {
            Uri imageUri = Uri.parse(imageUriStr);
            detailImage.setImageURI(imageUri);
        } else {
            int imageResId = getIntent().getIntExtra("imageResId", -1);
            if (imageResId != -1) {
                detailImage.setImageResource(imageResId);
            }
        }

        // 좋아요 처리
        int imageResId = getIntent().getIntExtra("imageResId", -1);
        liked = LikeManager.isLiked(this, imageResId);
        likeButton.setImageResource(liked ? R.drawable.ic_favorite : R.drawable.heart);

        likeButton.setOnClickListener(v -> {
            liked = !liked;
            if (liked) {
                likeButton.setImageResource(R.drawable.ic_favorite);
                LikeManager.like(this, imageResId);
            } else {
                likeButton.setImageResource(R.drawable.heart);
                LikeManager.unlike(this, imageResId);
            }
        });

        // 댓글 초기화
        commentAdapter = new CommentAdapter(commentList);
        commentRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        commentRecyclerView.setAdapter(commentAdapter);

        commentSubmitButton.setOnClickListener(v -> {
            String commentText = commentEditText.getText().toString().trim();
            if (!commentText.isEmpty()) {
                commentList.add(new CommentItem("익명", commentText));
                commentAdapter.notifyItemInserted(commentList.size() - 1);
                commentRecyclerView.scrollToPosition(commentList.size() - 1);
                commentEditText.setText("");
            }
        });

        // 더 찾아보기
        List<PhotoItem> moreList = new ArrayList<>();
        moreList.add(new PhotoItem(R.drawable.sample2, "shine"));
        moreList.add(new PhotoItem(R.drawable.sample3, "dailylook"));
        moreList.add(new PhotoItem(R.drawable.sample4, "friend"));
        moreList.add(new PhotoItem(R.drawable.sample5, "hoho"));

        PhotoAdapter moreAdapter = new PhotoAdapter(moreList);
        moreRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        moreRecyclerView.setAdapter(moreAdapter);
    }
}
