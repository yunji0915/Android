package com.example.photoproject;

import android.net.Uri;

public class PhotoItem {
    private Uri uri;
    private int imageResId;
    private String title;

    public PhotoItem(int imageResId, String title) {
        this.imageResId = imageResId;
        this.title = title;
    }

    public PhotoItem(Uri uri, String title) {
        this.uri = uri;
        this.title = title;
    }

    public boolean isUri() {
        return uri != null;
    }

    public Uri getUri() {
        return uri;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof PhotoItem)) return false;

        PhotoItem other = (PhotoItem) obj;

        if (uri != null && other.uri != null) {
            return uri.equals(other.uri);
        }

        return imageResId == other.imageResId && title.equals(other.title);
    }

    @Override
    public int hashCode() {
        int result = (uri != null) ? uri.hashCode() : 0;
        result = 31 * result + imageResId;
        result = 31 * result + title.hashCode();
        return result;
    }
}
