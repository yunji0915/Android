package com.example.photoproject;

public class CommentItem {
    private String text;
    private String writer;

    public CommentItem(String writer, String text) {
        this.writer = writer;
        this.text = text;
    }

    public String getWriter() {
        return writer;
    }

    public String getText() {
        return text;
    }
}

