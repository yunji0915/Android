package com.example.photoproject;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.GridLayoutManager;


import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.photoproject.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class FavoriteFragment extends Fragment {
    private RecyclerView recyclerView;
    private PhotoAdapter adapter;
    private List<PhotoItem> likedList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.favorite_fragment, container, false);

        recyclerView = view.findViewById(R.id.favoriteRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        likedList = new ArrayList<>();
        Set<String> likes = LikeManager.getLikes(getContext());

        for (String id : likes) {
            int resId = Integer.parseInt(id);
            likedList.add(new PhotoItem(resId, "데일리룩"));
        }

        adapter = new PhotoAdapter(likedList);
        recyclerView.setAdapter(adapter);

        return view;
    }
}
