package com.example.photoproject;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public class LikeManager {
    private static final String PREF_NAME = "liked_photos";
    private static final String KEY_LIKES = "likes";

    public static void like(Context context, int imageResId) {
        Set<String> likes = getLikes(context);
        likes.add(String.valueOf(imageResId));
        save(context, likes);
    }

    public static void unlike(Context context, int imageResId) {
        Set<String> likes = getLikes(context);
        likes.remove(String.valueOf(imageResId));
        save(context, likes);
    }

    public static boolean isLiked(Context context, int imageResId) {
        return getLikes(context).contains(String.valueOf(imageResId));
    }

    public static Set<String> getLikes(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return new HashSet<>(prefs.getStringSet(KEY_LIKES, new HashSet<>()));
    }

    private static void save(Context context, Set<String> likes) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putStringSet(KEY_LIKES, likes).apply();
    }
}
