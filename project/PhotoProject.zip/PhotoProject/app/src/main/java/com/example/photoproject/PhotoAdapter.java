
package com.example.photoproject;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder> {
    private List<PhotoItem> photoList;

    public PhotoAdapter(List<PhotoItem> photoList) {
        this.photoList = photoList;
    }

    public void updateList(List<PhotoItem> newList) {
        this.photoList = newList;
        notifyDataSetChanged();
    }


    public static class PhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView titleView;

        public PhotoViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.photoImageView);
            titleView = itemView.findViewById(R.id.photoTitle);
        }
    }

    @Override
    public PhotoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_photo, parent, false);
        return new PhotoViewHolder(view);
    }


    @Override
    public void onBindViewHolder(PhotoViewHolder holder, int position) {
        PhotoItem item = photoList.get(position);

        holder.imageView.post(() -> {
            int width = holder.imageView.getWidth();
            int height = (int) (width * 1.3);
            holder.imageView.getLayoutParams().height = height;
            holder.imageView.requestLayout();
        });

        if (item.isUri()) {
            Glide.with(holder.itemView.getContext())
                    .load(item.getUri())
                    .transform(new CenterCrop(), new RoundedCorners(24))
                    .into(holder.imageView);
        } else {
            Glide.with(holder.itemView.getContext())
                    .load(item.getImageResId())
                    .transform(new CenterCrop(), new RoundedCorners(24))
                    .into(holder.imageView);
        }
        holder.titleView.setText(item.getTitle());

        holder.imageView.setOnClickListener(v -> {
            int adapterPosition = holder.getAdapterPosition();
            if (adapterPosition != RecyclerView.NO_POSITION) {
                PhotoItem clickedItem = photoList.get(adapterPosition); // 정확한 아이템

                Intent intent = new Intent(v.getContext(), PhotoDetailActivity.class);
                if (clickedItem.isUri()) {
                    intent.putExtra("imageUri", clickedItem.getUri().toString());
                } else {
                    intent.putExtra("imageResId", clickedItem.getImageResId());
                }
                intent.putExtra("title", clickedItem.getTitle()); // 필요하면 title도 넘기기

                v.getContext().startActivity(intent);
            }
        });

    }

    // 🔥 이건 onBind 밖으로 빼야 함!
    @Override
    public int getItemCount() {
        return photoList.size();
    }
}
