package com.example.photoproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {
    private List<CommentItem> commentList;

    public CommentAdapter(List<CommentItem> commentList) {
        this.commentList = commentList;
    }

    public static class CommentViewHolder extends RecyclerView.ViewHolder {
        TextView writerView, commentView;

        public CommentViewHolder(View itemView) {
            super(itemView);
            writerView = itemView.findViewById(R.id.writerTextView);
            commentView = itemView.findViewById(R.id.commentTextView);
        }
    }

    @Override
    public CommentViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_comment, parent, false);
        return new CommentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CommentViewHolder holder, int position) {
        CommentItem item = commentList.get(position);
        holder.writerView.setText(item.getWriter());
        holder.commentView.setText(item.getText());
    }

    @Override
    public int getItemCount() {
        return commentList.size();
    }
}
