package com.example.photoproject;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;


import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.photoproject.R;

import java.util.ArrayList;
import java.util.List;

public class SearchFragment extends Fragment {
    private RecyclerView recyclerView;
    private EditText searchEditText;
    private PhotoAdapter adapter;
    private TextView emptyTextView;

    private List<PhotoItem> fullList = new ArrayList<>();
    private List<PhotoItem> filteredList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.search_fragment, container, false);

        // 뷰 초기화
        searchEditText = view.findViewById(R.id.searchEditText);
        recyclerView = view.findViewById(R.id.searchRecyclerView);
        emptyTextView = view.findViewById(R.id.emptyTextView);

        // 리사이클러뷰 레이아웃 매니저 설정
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        // 전체 사진 리스트 초기화
        fullList.clear();
        fullList.add(new PhotoItem(R.drawable.sample1, "shine"));
        fullList.add(new PhotoItem(R.drawable.sample2, "summer"));
        fullList.add(new PhotoItem(R.drawable.sample3, "cute"));
        fullList.add(new PhotoItem(R.drawable.sample4, "friend"));

        // 필터링된 리스트 초기화 및 어댑터 설정
        filteredList = new ArrayList<>(fullList);
        adapter = new PhotoAdapter(filteredList);
        recyclerView.setAdapter(adapter);

        // ✅ 텍스트 변경 시 필터링 적용
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Log.d("SearchDebug", "입력됨: " + s);
                filterPhotos(s.toString());
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        // ✅ 키보드 자동 표시
        searchEditText.requestFocus();
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(searchEditText, InputMethodManager.SHOW_IMPLICIT);
        }

        return view;
    }



    private void filterPhotos(String query) {
        List<PhotoItem> temp = new ArrayList<>();

        for (PhotoItem item : fullList) {
            if (item.getTitle().toLowerCase().contains(query.trim().toLowerCase())) {
                temp.add(item);
            }
        }

        if (temp.isEmpty()) {
            emptyTextView.setVisibility(View.VISIBLE);
        } else {
            emptyTextView.setVisibility(View.GONE);
        }

        adapter.updateList(temp);  // ✅ 여기에 정확히 넣으면 돼!
    }

}
