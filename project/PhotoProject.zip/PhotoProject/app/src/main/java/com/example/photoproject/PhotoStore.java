package com.example.photoproject;

import java.util.ArrayList;
import java.util.List;

public class PhotoStore {
    public static List<PhotoItem> uploadedPhotos = new ArrayList<>();
}
