package com.example.photoproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    private RecyclerView recyclerView;
    private PhotoAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.photoRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        // 🔐 오직 샘플만 사용
        List<PhotoItem> photoList = new ArrayList<>();
        photoList.add(new PhotoItem(R.drawable.sample1, "Photo"));
        photoList.add(new PhotoItem(R.drawable.sample2, "cap"));
        photoList.add(new PhotoItem(R.drawable.sample3, "travel"));
        photoList.add(new PhotoItem(R.drawable.sample4, "girlfriend"));
        photoList.add(new PhotoItem(R.drawable.sample5, "datelook"));
        photoList.add(new PhotoItem(R.drawable.sample6, "l want play!"));
        photoList.add(new PhotoItem(R.drawable.photo08, "hh"));

        adapter = new PhotoAdapter(photoList);
        recyclerView.setAdapter(adapter);

        return view;
    }


}
